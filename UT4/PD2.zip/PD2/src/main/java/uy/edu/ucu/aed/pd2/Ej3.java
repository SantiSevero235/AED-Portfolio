package uy.edu.ucu.aed.pd2;

public class Ej3 {
    public static void main (String[] args) {
        TArbolBB<String> arbol = new TArbolBB<>();
        String[] claves = ManejadorArchivosGenerico.leerArchivo("src/claves1.txt");
    }
}
